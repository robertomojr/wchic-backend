/**
 * Serviço legado desativado.
 * O gateway lead-first não usa mais este arquivo.
 */
export {};

